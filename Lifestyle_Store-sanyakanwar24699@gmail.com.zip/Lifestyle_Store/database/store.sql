-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 20, 2020 at 07:23 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `store`
--

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE IF NOT EXISTS `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `price`) VALUES
(1, 'Canon EOS', 36000),
(2, 'Nikon DSLR', 40000),
(3, 'Sony DSLR', 45000),
(4, 'Olympus DSLR', 50000),
(5, 'Titan Model #301', 5000),
(6, 'Titan Model #201', 3000),
(7, 'HMT Milan', 8000),
(8, 'Faber Luba #111', 2800),
(9, 'H&W', 800),
(10, 'Louis Phil', 1000),
(11, 'John Zok', 1500),
(12, 'Jhalsani', 1300),
(13, 'iphone 11pro Max', 100999),
(14, 'Samsung 8', 36000),
(15, 'One Plus 5t', 36000),
(16, 'Mi Mix 2', 36999),
(17, 'iphone X', 60000),
(18, 'Redmi K20 Pro', 29999),
(19, 'iphone 7 Plus', 39999),
(20, 'iphone 7', 29999),
(21, 'iphone 6S plus', 42250),
(22, 'Samsung Galaxy S8 plus', 64999),
(23, 'Samsung Galaxy Note8 Plus', 69999),
(24, 'Samsung Galaxy S7 Edge', 44999),
(25, 'Samsung Galaxy A8', 35999),
(26, 'One Plus 5t', 35999),
(27, 'One Plus 5', 32999),
(28, 'One Plus 3T', 35999),
(29, 'One plus 3', 29999),
(30, 'Mi Mix 2', 32999),
(31, 'Mi Max 2', 16999),
(32, 'Mi A1', 15999),
(33, 'Redmi Note 4', 13999),
(34, 'Oppo F11 Pro', 25999),
(35, 'Oppo F9', 20999),
(36, 'Oppo Reno', 25999),
(37, 'Nokia 9', 30999),
(38, 'Nokia 8', 15999),
(39, 'Nokia 7 Plus', 25999);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `contact`, `city`, `address`) VALUES
(1, 'sasuke k', 'gaurav.m@oracle.com', '3fc0a7acf087f549ac2b266baf94b8b1', '9999999999', 'asd', 'asd'),
(2, 'sanya kanwar', 'sanyakanwar@gmail.com', '8c811e1d5fca1bd9738780eac15b6a14', '9459738002', 'shimla', 'krishna bhawan sangti sanjauli'),
(3, 'kartikey', 'kartikeybhandari@gmail.com', '938cf12663474385198bd4a8e7be0ec9', '8628823681', 'kangra', 'bharmar'),
(4, 'kartikey', 'kartikeybhandari@gmail.com', '938cf12663474385198bd4a8e7be0ec9', '8628823681', 'jawali', 'bharmar'),
(5, 'sanya', 'sanyakanwar24699@gmail.com', '2bd5a2ae6c55f061afda67c408f2b50c', '8544734459', 'shimla', 'krishna bhawan'),
(6, 'garima kanwar', 'garima89881@gmail.com', '559648e7f8b07dc7de0508f55d376efa', '8988128922', 'solan', 'satya niwas'),
(7, 'raj verma', 'raj25@gmail.com', '0abd8badd7491bcdffb5f9e3c8c02da5', '9816545689', 'chamba', 'verma niwas'),
(8, 'sanya kanwar', 'sanyakanwar24699@gmail.com', '2bd5a2ae6c55f061afda67c408f2b50c', '4398347888', 'shimla', 'niwas '),
(9, 'sanya kanwar', 'sanyakanwar24699@gmail.com', '2bd5a2ae6c55f061afda67c408f2b50c', '3456789100', 'solan', 'bhawan'),
(10, 'sanya kan', 'sanyakanwar4699@gmail.com', '2bd5a2ae6c55f061afda67c408f2b50c', '1234567890', 'solan', 'bhawan'),
(11, 'sanya kanwar', 'sanyakanwar24699@gmail.com', '8c811e1d5fca1bd9738780eac15b6a14', '7689054321', 'solan', 'krishna bhawan'),
(12, 'ss ssss', 'sakaka@gmail.com', 'd550e990773906b3c481d01806ba05ef', '9459738002', 'ghati', 'ghatnagar'),
(13, 'jjj kkk', 'ddd@gmail.com', '3aed73af7998d6b7b4a1e3b1a70ae101', '9865234567', 'shimla', 'niwas '),
(14, 'sasuke k', 'sasu@gmail.com', '853bb3126ae8fe8684e2d32f7cbe88c5', '9812765433', 'solan', 'san niwas'),
(15, 'sss klk', 'sde23@gmail.com', 'c86df6362d543b1195934e7700ccb43e', '9856789432', 'fagu', 'bhawan'),
(16, 'kartikey sanya', 'taklu@gmail.com', '63ee56370916fe00ea47a4e2c778a28e', '8544734459', 'kangra', 'krishna bhawan'),
(17, 'sss kkk', 'sas@gmail.com', 'b6e22abd87f8a5060f7221e34b3ca91b', '9835478262', 'ghaty', 'bhawan nagar'),
(18, 'ghg kk', 'asd@gmail.com', '13af896f107776fb84681495dbde5aec', '9873767354', 'solan', 'sss niwas'),
(19, 'kartikey Bhandari', 'sannu004@gmail.com', '74ce123408776376c50ee43848ef9b73', '8628823681', 'kangra', 'bharmar'),
(20, 'san kkkkkkkk', 'sss@gmail.com', '4875b3210ffa9463be42c307d7e97c07', '9988746264', 'shimla', 'kdfjh dsfjhg');

-- --------------------------------------------------------

--
-- Table structure for table `users_items`
--

DROP TABLE IF EXISTS `users_items`;
CREATE TABLE IF NOT EXISTS `users_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `status` enum('Added to cart','Confirmed') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `item_id` (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_items`
--

INSERT INTO `users_items` (`id`, `user_id`, `item_id`, `status`) VALUES
(1, 1, 16, 'Confirmed'),
(2, 1, 15, 'Confirmed'),
(9, 2, 7, 'Confirmed'),
(13, 2, 4, 'Confirmed'),
(14, 2, 3, 'Confirmed'),
(15, 2, 4, 'Confirmed'),
(16, 2, 4, 'Confirmed'),
(17, 2, 4, 'Confirmed'),
(18, 2, 4, 'Confirmed'),
(19, 2, 4, 'Confirmed'),
(20, 2, 4, 'Confirmed'),
(21, 2, 4, 'Confirmed'),
(22, 2, 4, 'Confirmed'),
(23, 2, 4, 'Confirmed'),
(24, 2, 3, 'Confirmed'),
(25, 2, 15, 'Confirmed'),
(27, 2, 12, 'Confirmed'),
(28, 2, 1, 'Confirmed'),
(30, 14, 6, 'Confirmed'),
(31, 2, 3, 'Confirmed'),
(33, 2, 4, 'Confirmed'),
(34, 2, 3, 'Confirmed'),
(35, 2, 1, 'Confirmed'),
(36, 2, 2, 'Confirmed'),
(37, 2, 4, 'Confirmed'),
(38, 2, 12, 'Confirmed'),
(40, 2, 4, 'Confirmed'),
(42, 2, 12, 'Confirmed'),
(43, 2, 3, 'Confirmed'),
(44, 2, 12, 'Confirmed'),
(46, 2, 4, 'Confirmed'),
(47, 2, 1, 'Confirmed'),
(48, 2, 12, 'Confirmed'),
(49, 2, 4, 'Confirmed'),
(50, 2, 12, 'Confirmed'),
(51, 2, 4, 'Confirmed'),
(52, 2, 12, 'Confirmed'),
(53, 2, 12, 'Confirmed'),
(54, 2, 12, 'Confirmed'),
(55, 2, 12, 'Confirmed'),
(56, 2, 12, 'Confirmed'),
(57, 2, 4, 'Confirmed'),
(58, 2, 4, 'Confirmed'),
(59, 2, 4, 'Confirmed'),
(60, 2, 3, 'Confirmed'),
(61, 2, 11, 'Confirmed'),
(62, 2, 12, 'Confirmed'),
(64, 2, 12, 'Confirmed'),
(66, 2, 6, 'Confirmed'),
(67, 2, 12, 'Confirmed'),
(68, 2, 11, 'Confirmed'),
(69, 2, 12, 'Confirmed'),
(70, 2, 6, 'Confirmed'),
(71, 2, 3, 'Confirmed'),
(72, 2, 12, 'Confirmed'),
(73, 2, 6, 'Confirmed'),
(74, 2, 4, 'Confirmed'),
(75, 2, 1, 'Confirmed'),
(76, 2, 5, 'Confirmed'),
(77, 2, 12, 'Confirmed'),
(78, 19, 22, 'Added to cart'),
(79, 19, 14, 'Added to cart'),
(80, 19, 12, 'Confirmed'),
(81, 19, 4, 'Confirmed'),
(82, 19, 3, 'Confirmed'),
(83, 19, 6, 'Confirmed'),
(84, 2, 3, 'Confirmed'),
(85, 2, 4, 'Confirmed'),
(86, 2, 16, 'Confirmed'),
(87, 2, 13, 'Added to cart'),
(88, 2, 14, 'Added to cart'),
(89, 2, 15, 'Added to cart'),
(90, 2, 12, 'Confirmed'),
(91, 2, 18, 'Added to cart'),
(92, 2, 24, 'Added to cart'),
(93, 2, 30, 'Added to cart'),
(94, 2, 26, 'Added to cart'),
(95, 2, 17, 'Added to cart');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
